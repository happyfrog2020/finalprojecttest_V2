import * as d3 from 'd3';

const app = d3.select('div#app');

const margin = {top: 100, right: 20, bottom: 50, left: 190};
const WIDTH = 450 - margin.left - margin.right;
const HEIGHT = 350 - margin.top - margin.bottom;


const svg = app.append('svg');
svg.style('border', '0.1px solid red');
svg.attr('width', WIDTH);
svg.attr('height', HEIGHT);
svg.attr('viewBox', `0 0 ${WIDTH} ${HEIGHT}`);

d3.json('./women-stem.json').then(function(data) {
  //ex: https://www.w3schools.com/JSREF/jsref_filter.asp
  // filter gender data from the entire dataset
  const maleData = data.filter(d => d['Men']);
  const femaleData = data.filter(d => d['Women']);
  //mapping the majos
  const majors = Array.from(new Set(data.map(d => d['Major'])));
  //in each majors, search for each gender data
  const majorByGender = majors.map(major => {
  const maleCount = maleData.find(d => d['Major'] === major)['Men'];
  const femaleCount = femaleData.find(d => d['Major'] === major)['Women'];
  //retur the value to the array
  return { major, maleCount, femaleCount };
  });
//able to get male and female numbers for each major
  console.log(majorByGender);

const x_scale = d3
  .scaleBand()
  .domain(majorByGender.map(d => d.major))
  .range([0, WIDTH])
  .padding(0.2);

const y_scale = d3.scaleLinear()
  .domain([0, d3.max(majorByGender, d => d.maleCount + d.femaleCount)]) // Set the domain to cover the range of the data
  .range([HEIGHT, 0]);

const maleRects = svg.selectAll('.maleRect')
  .data(majorByGender)
  .enter()
  .append('rect')
  .attr('class', 'maleRect')
  .attr('x', d => x_scale(d.major))
  .attr('y', d => y_scale(d.maleCount))
  .attr('width', x_scale.bandwidth() / 2)
  .attr('height', d => HEIGHT - y_scale(d.maleCount))
  .attr('fill', 'blue');

const femaleRects = svg.selectAll('.femaleRect')
  .data(majorByGender)
  .enter()
  .append('rect')
  .attr('class', 'femaleRect')
  .attr('x', d => x_scale(d.major) + x_scale.bandwidth() / 2)
  .attr('y', d => y_scale(d.femaleCount))
  .attr('width', x_scale.bandwidth() / 2)
  .attr('height', d => HEIGHT - y_scale(d.femaleCount))
  .attr('fill', 'pink');

});
